
import React, { useState } from 'react';
import { geminiService } from '../services/geminiService';
import { ConsultantResult } from '../types';
import { MessageCircleQuestion, Loader2, ThumbsUp, ThumbsDown, Award, ArrowRight } from 'lucide-react';

interface ConsultantProps {
  onSendToCompiler?: (text: string) => void;
}

export const Consultant: React.FC<ConsultantProps> = ({ onSendToCompiler }) => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<ConsultantResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleConsult = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const response = await geminiService.judgeTone(input);
      setResult(response);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="space-y-3">
        <label className="text-[10px] font-black text-[#EEEEEE]/30 uppercase tracking-[0.2em] ml-2">Seu Dilema</label>
        <textarea
          className="w-full h-40 p-6 rounded-2xl bg-[#222831] border-none focus:ring-1 focus:ring-[#00ADB5] outline-none transition-all resize-none text-[#EEEEEE] text-lg font-medium leading-relaxed shadow-inner"
          placeholder="Ex: Devo pedir demissão agora para focar no meu projeto paralelo ou esperar mais 3 meses?"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
      </div>

      <button
        onClick={handleConsult}
        disabled={loading || !input}
        className="w-full py-5 bg-[#00ADB5] hover:bg-[#00ADB5]/80 text-[#222831] rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-3 shadow-xl active:scale-95"
      >
        {loading ? <Loader2 className="animate-spin" /> : <><MessageCircleQuestion size={20} /> Obter Perspectiva</>}
      </button>

      {result && (
        <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-700">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-6 bg-[#393E46]/30 rounded-2xl border border-[#00ADB5]/10 group">
              <div className="flex items-center gap-2 text-[#00ADB5] font-black text-[10px] uppercase tracking-widest mb-4">
                <ThumbsUp size={14} /> Prós
              </div>
              <ul className="space-y-3">
                {result.pros.map((pro, i) => (
                  <li key={i} className="text-sm text-[#EEEEEE]/80 font-bold flex gap-2">
                    <span className="text-[#00ADB5]">•</span> {pro}
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-6 bg-[#393E46]/30 rounded-2xl border border-red-400/10">
              <div className="flex items-center gap-2 text-red-400 font-black text-[10px] uppercase tracking-widest mb-4">
                <ThumbsDown size={14} /> Contras
              </div>
              <ul className="space-y-3">
                {result.cons.map((con, i) => (
                  <li key={i} className="text-sm text-[#EEEEEE]/80 font-bold flex gap-2">
                    <span className="text-red-400">•</span> {con}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="p-8 bg-[#222831] rounded-3xl border border-[#00ADB5]/30 text-[#EEEEEE] shadow-2xl relative group overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-[#00ADB5] font-black text-[10px] uppercase tracking-[0.2em]">
                <Award size={16} /> Veredito Final
              </div>
              {onSendToCompiler && (
                <button
                  onClick={() => onSendToCompiler(result.conclusion)}
                  className="text-[10px] font-bold text-[#00ADB5] hover:underline flex items-center gap-1"
                >
                  Extrair Tarefas <ArrowRight size={10} />
                </button>
              )}
            </div>
            <p className="text-xl leading-relaxed font-black tracking-tight text-[#EEEEEE]">
              {result.conclusion}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
