
import React, { useState } from 'react';
import { geminiService } from '../services/geminiService';
import { Sparkles, Copy, Check } from 'lucide-react';

export const Formalizer: React.FC = () => {
  const [text, setText] = useState('');
  const [tone, setTone] = useState('mais profissional');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const tones = [
    'mais profissional',
    'mais educado',
    'menos agressivo',
    'mais fácil de ler',
    'mais conciso',
    'mais amigável',
    'como um e-mail formal',
    'para um grupo de amigos',
    'correção ortográfica gentil'
  ];

  const handleFormalize = async () => {
    if (!text.trim()) return;
    setLoading(true);
    try {
      const output = await geminiService.formalizeText(text, tone);
      setResult(output);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      <div className="space-y-3">
        <label className="text-[10px] font-black text-[#EEEEEE]/30 uppercase tracking-[0.2em] ml-2">Texto Original</label>
        <textarea
          className="w-full h-44 p-6 rounded-2xl bg-[#222831] border-none focus:ring-1 focus:ring-[#00ADB5] outline-none transition-all resize-none text-[#EEEEEE] text-lg font-medium leading-relaxed"
          placeholder="Ex: Eu preciso dizer ao meu chefe que vou me atrasar de novo..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        
        <div className="flex flex-col sm:flex-row gap-3 items-center pt-2">
          <div className="flex-1 w-full">
            <select
              className="w-full px-4 py-4 rounded-xl !bg-[#222831] !border-[#EEEEEE]/10 text-sm font-bold text-[#EEEEEE] focus:ring-1 focus:ring-[#00ADB5] outline-none transition-all cursor-pointer appearance-none"
              value={tone}
              onChange={(e) => setTone(e.target.value)}
            >
              {tones.map((t) => (
                <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
              ))}
            </select>
          </div>
          <button
            onClick={handleFormalize}
            disabled={loading || !text}
            className="w-full sm:w-auto px-10 py-4 bg-[#00ADB5] hover:bg-[#00ADB5]/80 text-[#222831] rounded-xl font-black text-sm transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : <><Sparkles size={16} /> Ajustar Tom</>}
          </button>
        </div>
      </div>

      {result && (
        <div className="p-8 bg-[#393E46]/40 rounded-3xl border border-[#00ADB5]/20 shadow-2xl animate-in zoom-in-95 duration-500 relative group">
          <div className="absolute top-4 right-4">
            <button
              onClick={copyToClipboard}
              className="p-2 bg-[#222831] text-[#00ADB5] rounded-lg transition-colors flex items-center gap-2 text-[10px] font-black uppercase tracking-widest border border-[#00ADB5]/20 hover:bg-[#00ADB5] hover:text-[#222831]"
            >
              {copied ? <><Check size={14} /> Copiado</> : <><Copy size={14} /> Copiar</>}
            </button>
          </div>
          <p className="text-[#EEEEEE] text-lg leading-relaxed font-bold pr-12">{result}</p>
        </div>
      )}
    </div>
  );
};

const Loader2 = ({ className, size }: { className?: string, size?: number }) => (
  <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
);
