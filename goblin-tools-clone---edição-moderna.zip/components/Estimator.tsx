
import React, { useState } from 'react';
import { geminiService } from '../services/geminiService';
import { Clock, Timer, Loader2, Compass } from 'lucide-react';

export const Estimator: React.FC = () => {
  const [task, setTask] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleEstimate = async () => {
    if (!task.trim()) return;
    setLoading(true);
    try {
      const estimate = await geminiService.estimateTime(task);
      setResult(estimate);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="space-y-3">
        <label className="text-[10px] font-black text-[#EEEEEE]/30 uppercase tracking-[0.2em] ml-2">Tarefa ou Projeto</label>
        <div className="p-1 bg-[#222831]/50 rounded-2xl border border-[#EEEEEE]/5">
          <input
            type="text"
            className="w-full px-6 py-4 rounded-xl !bg-transparent !border-none text-[#EEEEEE] text-lg font-medium shadow-none focus:ring-0"
            placeholder="Ex: Escrever um artigo de 500 palavras"
            value={task}
            onChange={(e) => setTask(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleEstimate()}
          />
        </div>
      </div>

      <button
        onClick={handleEstimate}
        disabled={loading || !task}
        className="w-full py-5 bg-[#393E46] hover:bg-[#393E46]/80 text-[#00ADB5] border border-[#00ADB5]/20 rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-3 shadow-lg active:scale-[0.98]"
      >
        {loading ? <Loader2 className="animate-spin" /> : <><Timer size={22} /> Calcular Esforço Real</>}
      </button>

      {result && (
        <div className="animate-in zoom-in-95 duration-500">
          <div className="p-8 bg-[#222831] rounded-3xl border border-[#00ADB5]/20 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-6 opacity-[0.03] group-hover:opacity-[0.07] transition-opacity">
               <Compass size={120} className="text-[#00ADB5]" />
            </div>
            <div className="flex items-center gap-2 text-[#00ADB5] font-black text-[10px] uppercase tracking-widest mb-6">
              <Clock size={14} /> Diagnóstico da IA
            </div>
            <p className="text-[#EEEEEE] text-lg leading-relaxed font-bold relative z-10 whitespace-pre-wrap">{result}</p>
          </div>
        </div>
      )}
    </div>
  );
};
