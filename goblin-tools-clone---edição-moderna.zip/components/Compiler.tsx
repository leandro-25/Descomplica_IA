
import React, { useState, useEffect } from 'react';
import { geminiService } from '../services/geminiService';
import { ListPlus, Loader2, Sparkles, Wand2, ArrowRight } from 'lucide-react';

interface CompilerProps {
  preloadValue?: string;
  onClearPreload?: () => void;
  onSendToMagicTodo?: (payload: string | string[]) => void;
}

export const Compiler: React.FC<CompilerProps> = ({ preloadValue, onClearPreload, onSendToMagicTodo }) => {
  const [input, setInput] = useState(preloadValue || '');
  const [results, setResults] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (preloadValue) setInput(preloadValue); }, [preloadValue]);

  const handleCompile = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      const tasks = await geminiService.compileTasks(input);
      setResults(tasks);
      if (onClearPreload) onClearPreload();
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="space-y-3">
        <label className="text-[10px] font-black text-[#EEEEEE]/30 uppercase tracking-[0.2em] ml-2">Brain Dump (Despeje seus pensamentos)</label>
        <div className="relative group">
          <textarea
            className="w-full h-56 p-6 rounded-2xl bg-[#222831] border-none focus:ring-1 focus:ring-[#00ADB5] outline-none transition-all resize-none text-[#EEEEEE] leading-relaxed"
            placeholder="Ex: Preciso organizar o aniversário, comprar bolo, balões, convidar o pessoal do trabalho, mas antes tenho que limpar a sala e ver se o som tá funcionando..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
        </div>
      </div>

      <button
        onClick={handleCompile}
        disabled={loading || !input}
        className="w-full py-5 bg-[#00ADB5] hover:bg-[#00ADB5]/80 text-[#222831] rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-3 disabled:opacity-50 active:scale-[0.98]"
      >
        {loading ? <Loader2 className="animate-spin" /> : <><Sparkles size={20} /> Transformar em Plano</>}
      </button>

      {results.length > 0 && (
        <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-700">
          <div className="flex items-center justify-between border-b border-[#393E46] pb-4">
            <h3 className="font-bold text-[#EEEEEE] flex items-center gap-2">
              <ListPlus size={18} className="text-[#00ADB5]" />
              Lista de Tarefas
            </h3>
            
            {onSendToMagicTodo && (
              <button
                onClick={() => onSendToMagicTodo(results)}
                className="text-[10px] font-black uppercase tracking-widest px-4 py-2 bg-[#00ADB5]/10 text-[#00ADB5] rounded-lg hover:bg-[#00ADB5]/20 transition-all"
              >
                <Wand2 size={12} className="inline mr-1" /> Exportar Tudo
              </button>
            )}
          </div>
          
          <div className="grid gap-2">
            {results.map((task, i) => (
              <div 
                key={i} 
                className="p-4 bg-[#222831]/40 rounded-xl border border-[#EEEEEE]/5 flex items-center justify-between gap-4 hover:border-[#00ADB5]/30 transition-all group"
              >
                <span className="text-sm font-medium text-[#EEEEEE]/80">{task}</span>
                {onSendToMagicTodo && (
                  <button
                    onClick={() => onSendToMagicTodo(task)}
                    className="shrink-0 w-8 h-8 bg-[#393E46] text-[#00ADB5] rounded-lg opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center hover:bg-[#00ADB5] hover:text-[#222831]"
                  >
                    <ArrowRight size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
