
import React, { useState, useEffect, useMemo } from 'react';
import { geminiService } from '../services/geminiService';
import { TaskItem } from '../types';
import { 
  Wand2, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  Flame, 
  ChevronDown, 
  ChevronRight,
  Loader2,
  Clock,
  ShieldCheck,
  Timer,
  Zap,
  CalendarDays
} from 'lucide-react';

interface MagicTodoProps {
  preloadTasks?: string[];
  onClearPreload?: () => void;
}

export const MagicTodo: React.FC<MagicTodoProps> = ({ preloadTasks, onClearPreload }) => {
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [spiciness, setSpiciness] = useState(3);
  const [isEstimatingAll, setIsEstimatingAll] = useState(false);

  useEffect(() => {
    if (preloadTasks && preloadTasks.length > 0) {
      const newTasks: TaskItem[] = preloadTasks.map(text => ({
        id: Math.random().toString(36).substr(2, 9),
        text: text.trim(),
        isCompleted: false,
        isExpanded: true
      }));
      setTasks(prev => [...newTasks, ...prev]);
      if (onClearPreload) onClearPreload();
    }
  }, [preloadTasks]);

  const addTask = (text: string) => {
    if (!text.trim()) return;
    const newTask: TaskItem = {
      id: Math.random().toString(36).substr(2, 9),
      text: text.trim(),
      isCompleted: false,
      isExpanded: true
    };
    setTasks(prev => [newTask, ...prev]);
    setInputValue('');
  };

  const updateTaskRecursive = (list: TaskItem[], id: string, updater: (task: TaskItem) => TaskItem): TaskItem[] => {
    return list.map(task => {
      if (task.id === id) return updater(task);
      if (task.subTasks) {
        return { ...task, subTasks: updateTaskRecursive(task.subTasks, id, updater) };
      }
      return task;
    });
  };

  const removeTaskRecursive = (list: TaskItem[], id: string): TaskItem[] => {
    return list
      .filter(task => task.id !== id)
      .map(task => ({
        ...task,
        subTasks: task.subTasks ? removeTaskRecursive(task.subTasks, id) : undefined
      }));
  };

  const toggleTask = (id: string) => {
    setTasks(prev => updateTaskRecursive(prev, id, (t) => ({ ...t, isCompleted: !t.isCompleted })));
  };

  const toggleExpand = (id: string) => {
    setTasks(prev => updateTaskRecursive(prev, id, (t) => ({ ...t, isExpanded: !t.isExpanded })));
  };

  const removeTask = (id: string) => {
    setTasks(prev => removeTaskRecursive(prev, id));
  };

  const handleMagic = async (id: string, text: string) => {
    setTasks(prev => updateTaskRecursive(prev, id, (t) => ({ ...t, isMagicLoading: true, isExpanded: true })));
    try {
      const subTasksTexts = await geminiService.breakDownTask(text, spiciness);
      const newSubTasks: TaskItem[] = subTasksTexts.map(t => ({
        id: Math.random().toString(36).substr(2, 9),
        text: t,
        isCompleted: false,
        isExpanded: true
      }));
      setTasks(prev => updateTaskRecursive(prev, id, (t) => ({ 
        ...t, 
        subTasks: [...(t.subTasks || []), ...newSubTasks], 
        isMagicLoading: false 
      })));
    } catch (error) {
      console.error(error);
      setTasks(prev => updateTaskRecursive(prev, id, (t) => ({ ...t, isMagicLoading: false })));
    }
  };

  const estimateTimeForSingleTask = async (mainTask: TaskItem) => {
    setTasks(prev => updateTaskRecursive(prev, mainTask.id, (t) => ({ 
      ...t, 
      isMagicLoading: true,
      subTasks: t.subTasks?.map(st => ({ ...st, isMagicLoading: true }))
    })));
    try {
      const subtaskTexts = mainTask.subTasks?.map(st => st.text) || [];
      const result = await geminiService.estimateTaskTimeDetailed(mainTask.text, subtaskTexts);
      setTasks(prev => updateTaskRecursive(prev, mainTask.id, (t) => {
        const updatedParent = {
          ...t,
          estimatedMinutes: result.mainMinutes,
          timeLabel: result.mainLabel,
          isMagicLoading: false
        };
        if (updatedParent.subTasks && result.subtasksEstimates.length === updatedParent.subTasks.length) {
          updatedParent.subTasks = updatedParent.subTasks.map((st, index) => ({
            ...st,
            estimatedMinutes: result.subtasksEstimates[index].minutes,
            timeLabel: result.subtasksEstimates[index].label,
            isMagicLoading: false
          }));
        } else if (updatedParent.subTasks) {
          updatedParent.subTasks = updatedParent.subTasks.map(st => ({ ...st, isMagicLoading: false }));
        }
        return updatedParent;
      }));
    } catch (error) {
      console.error(error);
      setTasks(prev => updateTaskRecursive(prev, mainTask.id, (t) => ({ 
        ...t, 
        isMagicLoading: false,
        subTasks: t.subTasks?.map(st => ({ ...st, isMagicLoading: false }))
      })));
    }
  };

  const handleEstimateAll = async () => {
    if (tasks.length === 0) return;
    setIsEstimatingAll(true);
    await Promise.all(tasks.map(task => estimateTimeForSingleTask(task)));
    setIsEstimatingAll(false);
  };

  const totalMinutes = useMemo(() => {
    let total = 0;
    tasks.forEach(task => { total += task.estimatedMinutes || 0; });
    return total;
  }, [tasks]);

  const totalWithMargin = Math.round(totalMinutes * 1.25);

  const formatMinutes = (mins: number) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    if (h > 0) return `${h}h${m > 0 ? ` ${m}m` : ''}`;
    return `${m} min`;
  };

  const getDaysWorkload = (mins: number) => {
    const MINUTES_PER_DAY = 360; // 6h produtivas
    const days = mins / MINUTES_PER_DAY;
    if (days < 0.1) return "< 1 hora";
    if (days < 1) return `${(days * 6).toFixed(1)}h de esforço`;
    return `${days.toFixed(1)} dias de foco`;
  };

  const TaskRow: React.FC<{ task: TaskItem; level?: number }> = ({ task, level = 0 }) => {
    const hasSubtasks = task.subTasks && task.subTasks.length > 0;
    return (
      <div className={`flex flex-col ${level > 0 ? 'ml-6 mt-2' : 'mb-3'}`}>
        <div className={`group flex items-center gap-3 p-4 rounded-2xl transition-all border ${
          level === 0 ? 'bg-[#222831]/30 border-[#EEEEEE]/5 shadow-sm' : 'bg-transparent border-transparent hover:bg-[#222831]/20'
        } ${task.isCompleted ? 'opacity-30 grayscale' : ''}`}>
          
          <button 
            onClick={() => toggleExpand(task.id)}
            className={`w-6 h-6 flex items-center justify-center rounded-lg hover:bg-[#EEEEEE]/10 transition-colors ${!hasSubtasks && !task.isMagicLoading ? 'invisible' : ''}`}
          >
            {task.isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </button>

          <button onClick={() => toggleTask(task.id)} className="shrink-0 transition-transform active:scale-75">
            {task.isCompleted ? <CheckCircle2 className="text-[#00ADB5]" size={20} /> : <Circle className="text-[#EEEEEE]/20 group-hover:text-[#00ADB5]" size={20} />}
          </button>

          <div className="flex-1 flex flex-col md:flex-row md:items-center gap-2 overflow-hidden">
            <span className={`text-sm md:text-base truncate font-semibold ${task.isCompleted ? 'line-through text-[#EEEEEE]/40' : 'text-[#EEEEEE]'}`}>
              {task.text}
            </span>
            {task.timeLabel && !task.isMagicLoading && (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#00ADB5]/10 text-[#00ADB5] text-[9px] font-black rounded-full border border-[#00ADB5]/20 animate-in zoom-in-50 shrink-0">
                <Clock size={10} /> {task.timeLabel}
              </span>
            )}
            {task.isMagicLoading && (
               <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#EEEEEE]/5 text-[#EEEEEE]/40 text-[9px] font-bold rounded-full animate-pulse shrink-0">
                <Loader2 size={10} className="animate-spin" /> Mágica...
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
            {level === 0 && (
              <button onClick={() => estimateTimeForSingleTask(task)} disabled={task.isMagicLoading} className="p-2 text-[#00ADB5] hover:bg-[#00ADB5]/10 rounded-lg transition-colors" title='Estimar tempo'>
                <Timer size={16} />
              </button>
            )}
            <button onClick={() => handleMagic(task.id, task.text)} disabled={task.isMagicLoading} className="p-2 text-[#00ADB5] hover:bg-[#00ADB5]/10 rounded-lg transition-colors" title='Dividir tarefa'>
              <Wand2 size={16} />
            </button>
            <button onClick={() => removeTask(task.id)} className="p-2 text-[#EEEEEE]/20 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors">
              <Trash2 size={16} />
            </button>
          </div>
        </div>
        {task.isExpanded && hasSubtasks && (
          <div className="border-l border-[#00ADB5]/20 ml-3 pl-1 animate-in slide-in-from-top-1">
            {task.subTasks!.map(sub => <TaskRow key={sub.id} task={sub} level={level + 1} />)}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-8 relative">
      <div className="flex flex-col md:flex-row gap-3 p-1.5 bg-[#222831]/50 rounded-[2.5rem] border border-[#EEEEEE]/5 shadow-inner">
        <input
          type="text"
          className="flex-1 px-8 py-5 rounded-[2rem] !bg-transparent !border-none text-lg font-medium shadow-none focus:ring-0"
          placeholder="O que você precisa fazer?"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addTask(inputValue)}
        />
        <button
          onClick={() => addTask(inputValue)}
          className="px-10 py-5 bg-[#00ADB5] hover:bg-[#00ADB5]/80 text-[#222831] rounded-[2rem] font-black transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2"
        >
          <Plus size={20} /> Adicionar
        </button>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-6 bg-[#222831]/30 p-6 rounded-[2rem] border border-[#EEEEEE]/5">
        <div className="flex items-center gap-4 flex-1 max-w-md">
          <div className="flex items-center gap-2 text-[#EEEEEE]/40 font-black text-[10px] shrink-0 tracking-widest uppercase">
            <Flame size={14} className="text-orange-500" />
            Detalhes
          </div>
          <input
            type="range" min="1" max="5" value={spiciness}
            onChange={(e) => setSpiciness(parseInt(e.target.value))}
            className="flex-1 h-1.5 bg-[#222831] rounded-full appearance-none cursor-pointer accent-[#00ADB5]"
          />
          <span className="font-black text-[#00ADB5] text-lg w-4">{spiciness}</span>
        </div>
        
        {tasks.length > 0 && (
          <button
            onClick={handleEstimateAll}
            disabled={isEstimatingAll}
            className="flex items-center gap-2 px-8 py-4 bg-[#393E46] hover:bg-[#393E46]/80 text-[#00ADB5] rounded-2xl font-black text-[10px] tracking-widest uppercase border border-[#00ADB5]/20 transition-all active:scale-95 disabled:opacity-50"
          >
            {isEstimatingAll ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} className="fill-[#00ADB5]" />}
            Estimar Todos
          </button>
        )}
      </div>

      <div className="space-y-1">
        {tasks.map((task) => <TaskRow key={task.id} task={task} />)}
        {tasks.length === 0 && (
          <div className="text-center py-20 flex flex-col items-center gap-4 opacity-10">
            <Wand2 size={64} strokeWidth={1} />
            <p className="font-bold italic text-lg tracking-tighter">Sua jornada começa com o primeiro passo...</p>
          </div>
        )}
      </div>

      {totalMinutes > 0 && (
        <div className="mt-20 p-8 glass bg-[#393E46]/60 border border-[#00ADB5]/20 rounded-[2.5rem] shadow-2xl animate-in slide-in-from-bottom-8 duration-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center md:divide-x divide-[#EEEEEE]/5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#222831] rounded-2xl flex items-center justify-center text-[#EEEEEE]/40">
                <Clock size={24} />
              </div>
              <div>
                <p className="text-[10px] font-black text-[#EEEEEE]/30 uppercase tracking-widest mb-1">Tempo Bruto</p>
                <p className="text-xl font-black text-[#EEEEEE]">{formatMinutes(totalMinutes)}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 md:px-8">
              <div className="w-12 h-12 bg-[#00ADB5]/10 rounded-2xl flex items-center justify-center text-[#00ADB5]">
                <ShieldCheck size={24} />
              </div>
              <div>
                <p className="text-[10px] font-black text-[#00ADB5]/60 uppercase tracking-widest mb-1">Seguro (+25%)</p>
                <p className="text-xl font-black text-[#00ADB5]">{formatMinutes(totalWithMargin)}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 md:px-8">
              <div className="w-12 h-12 bg-[#222831] rounded-2xl flex items-center justify-center text-[#00ADB5]/40">
                <CalendarDays size={24} />
              </div>
              <div>
                <p className="text-[10px] font-black text-[#EEEEEE]/30 uppercase tracking-widest mb-1">Carga de Foco</p>
                <p className="text-xl font-black text-[#EEEEEE]/80">~ {getDaysWorkload(totalWithMargin)}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
