
import { GoogleGenAI, Type } from "@google/genai";
import { ChefRecipe, ConsultantResult } from '../types';

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const geminiService = {
  async breakDownTask(task: string, spiciness: number): Promise<string[]> {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Você é um assistente de disfunção executiva. 
      Divida a tarefa: "${task}" em etapas menores. 
      Nível de detalhamento: ${spiciness}/5.
      No nível 5, inclua até os mínimos detalhes (ex: "abrir o navegador", "pegar a chave").
      Responda em Português do Brasil.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
      },
    });
    return JSON.parse(response.text || "[]");
  },

  async estimateTaskTimeDetailed(task: string, subtasks: string[] = []): Promise<{ 
    mainMinutes: number; 
    mainLabel: string;
    subtasksEstimates: { minutes: number; label: string }[] 
  }> {
    const ai = getAI();
    const subCtx = subtasks.length > 0 ? `Etapas: ${subtasks.join(', ')}` : 'Sem etapas definidas.';
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Estime o tempo para: "${task}". 
      ${subCtx}
      
      REGRAS PARA REALISMO (MUITO IMPORTANTE):
      1. O tempo total (mainMinutes) DEVE ser a soma de todas as sub-tarefas mais um "Imposto de Transição" de 15 a 20%.
      2. Dividir tarefas AUMENTA o tempo total real, pois começar e parar gasta energia mental.
      3. Seja extremamente generoso com o tempo (neurodivergentes costumam subestimar por 2x).
      4. JAMAIS repita o nome da tarefa nos labels. Use apenas durações formatadas (ex: "1h 20m").`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            mainMinutes: { type: Type.INTEGER },
            mainLabel: { type: Type.STRING },
            subtasksEstimates: { 
              type: Type.ARRAY, 
              items: { 
                type: Type.OBJECT,
                properties: {
                  minutes: { type: Type.INTEGER },
                  label: { type: Type.STRING }
                }
              } 
            },
          },
          required: ["mainMinutes", "mainLabel", "subtasksEstimates"]
        },
      },
    });
    return JSON.parse(response.text || '{}');
  },

  async judgeTone(text: string): Promise<ConsultantResult> {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analise o dilema: "${text}". Seja um consultor pragmático e acolhedor.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            pros: { type: Type.ARRAY, items: { type: Type.STRING } },
            cons: { type: Type.ARRAY, items: { type: Type.STRING } },
            conclusion: { type: Type.STRING },
          },
          required: ["pros", "cons", "conclusion"]
        },
      },
    });
    return JSON.parse(response.text || "{}");
  },

  async estimateTime(task: string): Promise<string> {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Dê uma estimativa de tempo honesta e generosa para: "${task}". Explique por que leva esse tempo em Português-BR.`,
    });
    return response.text || "Sem resposta.";
  },

  async compileTasks(brainDump: string): Promise<string[]> {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Extraia uma lista de tarefas organizada deste texto: "${brainDump}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
      },
    });
    return JSON.parse(response.text || "[]");
  },

  async formalizeText(text: string, tone: string): Promise<string> {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Reescreva o texto: "${text}" para soar ${tone}.`,
    });
    return response.text || "";
  }
};
