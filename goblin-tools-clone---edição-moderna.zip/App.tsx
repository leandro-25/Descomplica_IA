
import React, { useState } from 'react';
import { ToolType } from './types';
import { MagicTodo } from './components/MagicTodo';
import { Compiler } from './components/Compiler';
import { Estimator } from './components/Estimator';
import { Consultant } from './components/Consultant';
import { Formalizer } from './components/Formalizer';
import { 
  Wand2, 
  Clock, 
  LayoutList, 
  MessageCircleQuestion,
  Sparkles,
  Zap,
  AlignLeft
} from 'lucide-react';

const App: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ToolType | 'formalizer'>('magic-todo');
  const [compilerPreload, setCompilerPreload] = useState('');
  const [magicTodoPreload, setMagicTodoPreload] = useState<string[]>([]);

  const tools = [
    { id: 'magic-todo', name: 'Magic To-Do', icon: Wand2 },
    { id: 'compiler', name: 'Compiler', icon: LayoutList },
    { id: 'estimator', name: 'Estimator', icon: Clock },
    { id: 'consultant', name: 'Consultant', icon: MessageCircleQuestion },
    { id: 'formalizer', name: 'Formalizer', icon: AlignLeft },
  ];

  const handleSendToCompiler = (text: string) => {
    setCompilerPreload(text);
    setActiveTool('compiler');
  };

  const handleSendToMagicTodo = (payload: string | string[]) => {
    const tasks = Array.isArray(payload) ? payload : [payload];
    setMagicTodoPreload(tasks);
    setActiveTool('magic-todo');
  };

  const renderTool = () => {
    switch (activeTool) {
      case 'magic-todo': return <MagicTodo preloadTasks={magicTodoPreload} onClearPreload={() => setMagicTodoPreload([])} />;
      case 'compiler': return <Compiler preloadValue={compilerPreload} onClearPreload={() => setCompilerPreload('')} onSendToMagicTodo={handleSendToMagicTodo} />;
      case 'estimator': return <Estimator />;
      case 'consultant': return <Consultant onSendToCompiler={handleSendToCompiler} />;
      case 'formalizer': return <Formalizer />;
      default: return <MagicTodo />;
    }
  };

  return (
    <div className="min-h-screen bg-[#222831] text-[#EEEEEE] selection:bg-[#00ADB5]/30 flex flex-col items-center">
      {/* Decoração de Fundo */}
      <div className="fixed inset-0 pointer-events-none -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-[#00ADB5]/5 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-[#00ADB5]/5 blur-[120px] rounded-full" />
      </div>

      {/* Floating Header Navigation */}
      <header className="fixed top-6 z-50 w-[95%] max-w-4xl">
        <nav className="glass bg-[#393E46]/80 border border-[#EEEEEE]/10 rounded-full px-2 py-2 shadow-2xl flex items-center justify-between">
          <div className="flex items-center gap-3 ml-4">
             <Sparkles size={18} className="text-[#00ADB5]" />
             <span className="font-display font-black text-sm tracking-tighter hidden sm:block">Goblin<span className="text-[#00ADB5]">.</span>tools</span>
          </div>
          
          <div className="flex items-center gap-1">
            {tools.map((tool) => {
              const Icon = tool.icon;
              const isActive = activeTool === tool.id;
              return (
                <button
                  key={tool.id}
                  onClick={() => setActiveTool(tool.id as any)}
                  className={`relative flex items-center justify-center p-2.5 sm:px-4 sm:py-2.5 rounded-full transition-all duration-300 group ${
                    isActive 
                      ? 'bg-[#00ADB5] text-[#222831] shadow-lg shadow-[#00ADB5]/20' 
                      : 'text-[#EEEEEE]/40 hover:text-[#EEEEEE] hover:bg-[#EEEEEE]/5'
                  }`}
                  title={tool.name}
                >
                  <Icon size={18} strokeWidth={isActive ? 2.5 : 2} />
                  <span className={`ml-2 text-xs font-bold transition-all duration-300 overflow-hidden ${isActive ? 'max-w-[100px] opacity-100' : 'max-w-0 opacity-0'} hidden md:block`}>
                    {tool.name}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mr-2 hidden sm:block">
            <div className="w-8 h-8 rounded-full bg-[#222831] flex items-center justify-center text-[10px] font-black border border-[#EEEEEE]/5 text-[#00ADB5]">
              AI
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section / Welcome */}
      <section className="mt-32 mb-10 text-center space-y-4 animate-in fade-in slide-in-from-top-4 duration-1000">
        <h1 className="text-4xl md:text-6xl font-black tracking-tight font-display">
          Descomplique seu <span className="text-[#00ADB5]">Cérebro</span>
        </h1>
        <p className="text-[#EEEEEE]/50 font-medium max-w-lg mx-auto px-4">
          Ferramentas inteligentes para ajudar com disfunção executiva e foco.
        </p>
      </section>

      {/* Main Container */}
      <main className="w-full max-w-4xl px-4 pb-24">
        <div className="glass bg-[#393E46]/40 rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative min-h-[500px] border border-[#EEEEEE]/5 overflow-hidden">
          {/* Tool Identifier */}
          <div className="mb-10 flex items-center gap-3">
             <div className="w-10 h-10 rounded-2xl bg-[#00ADB5]/10 flex items-center justify-center text-[#00ADB5]">
               {React.createElement(tools.find(t => t.id === activeTool)?.icon || Wand2, { size: 20 })}
             </div>
             <div className="space-y-0.5">
               <h2 className="text-2xl font-black text-[#EEEEEE] tracking-tight">
                 {tools.find(t => t.id === activeTool)?.name}
               </h2>
               <div className="flex items-center gap-2">
                 <Zap size={10} className="text-[#00ADB5] fill-[#00ADB5]" />
                 <span className="text-[9px] font-black uppercase tracking-widest text-[#00ADB5]">Modo de Inteligência Ativo</span>
               </div>
             </div>
          </div>

          <div className="animate-in fade-in zoom-in-95 duration-500">
            {renderTool()}
          </div>
        </div>

        {/* Action Suggestion */}
        <div className="mt-6 flex flex-col md:flex-row gap-4">
          <div className="flex-1 glass bg-[#393E46]/20 p-5 rounded-3xl flex items-center gap-4 text-xs font-semibold text-[#EEEEEE]/40 border border-[#EEEEEE]/5">
            <Zap size={16} className="text-[#00ADB5]" />
            Dica: Use o 'Compiler' para transformar anotações confusas em tarefas para o 'Magic To-Do'.
          </div>
        </div>
      </main>

      <footer className="w-full max-w-4xl border-t border-[#393E46] py-10 px-4 flex flex-col sm:flex-row items-center justify-between gap-6 text-[#EEEEEE]/20 text-[10px] font-bold uppercase tracking-[0.2em]">
        <div className="flex gap-8">
          <a href="#" className="hover:text-[#00ADB5] transition-colors">Privacidade</a>
          <a href="#" className="hover:text-[#00ADB5] transition-colors">Código Aberto</a>
          <a href="#" className="hover:text-[#00ADB5] transition-colors">Doação</a>
        </div>
        <p className="normal-case italic opacity-50">Goblin Tools &copy; {new Date().getFullYear()} - Brasil</p>
      </footer>
    </div>
  );
};

export default App;
